<html>
<head>
<title>Bhalo Achee - Login</title>
</head>

<body>
<h2>Login Here</h2>
<form action="login_submit.php" method="post">
<fieldset>
<p>
<label for="user_name">Username</label>
<input type="text" id="user_name" name="user_name" value="" maxlength="20" />
</p>
<p>
<label for="user_pass">Password</label>
<input type="text" id="user_pass" name="user_pass" value="" maxlength="20" />
</p>
<p>
<input type="submit" value="? Login" />
</p>
</fieldset>
</form>
</body>
</html>